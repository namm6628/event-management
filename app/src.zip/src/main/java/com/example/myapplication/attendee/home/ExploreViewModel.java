package com.example.myapplication.attendee.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.example.myapplication.common.DummyData;
import com.example.myapplication.common.model.Event;

import java.util.ArrayList;
import java.util.List;

public class ExploreViewModel extends ViewModel {
    private final SavedStateHandle state;
    private final MutableLiveData<List<Event>> events = new MutableLiveData<>();
    private List<Event> source = new ArrayList<>();

    // Keys lưu trạng thái
    private static final String K_Q = "query";
    private static final String K_CAT = "category";
    private static final String K_CITY = "city";

    public ExploreViewModel(SavedStateHandle handle) {
        this.state = handle;
        if (!state.contains(K_Q)) state.set(K_Q, "");
        if (!state.contains(K_CAT)) state.set(K_CAT, "");
        if (!state.contains(K_CITY)) state.set(K_CITY, "");
    }

    public LiveData<List<Event>> getEvents() { return events; }

    public void initIfNeeded() {
        if (source.isEmpty()) source = DummyData.getEvents();
        applyAll();
    }

    public void setQuery(String q) {
        state.set(K_Q, q == null ? "" : q.trim());
        applyAll();
    }

    public void setCategory(String c) {
        state.set(K_CAT, c == null ? "" : c.trim());
        applyAll();
    }

    public void setCity(String city) {
        state.set(K_CITY, city == null ? "" : city.trim());
        applyAll();
    }

    public String getQuery() { return state.get(K_Q); }
    public String getCategory() { return state.get(K_CAT); }
    public String getCity() { return state.get(K_CITY); }

    private void applyAll() {
        String q    = safeLower(getQuery());
        String cat  = safeLower(getCategory()); // ví dụ "âm nhạc"
        String city = safeLower(getCity());

        List<Event> out = new ArrayList<>();
        for (Event e : source) {
            String tTitle = safeLower(e.title);
            String tCat   = safeLower(e.category); // "âm nhạc", "sân khấu", ...
            String tVenue = safeLower(e.venue);

            boolean ok = true;
            if (!q.isEmpty())    ok &= tTitle.contains(q);
            if (!cat.isEmpty())  ok &= tCat.equals(cat);      // so sánh đúng tiếng Việt
            if (!city.isEmpty()) ok &= tVenue.contains(city);

            if (ok) out.add(e);
        }
        events.setValue(out);
    }

    private String safeLower(String s) { return s == null ? "" : s.toLowerCase(); }

}
